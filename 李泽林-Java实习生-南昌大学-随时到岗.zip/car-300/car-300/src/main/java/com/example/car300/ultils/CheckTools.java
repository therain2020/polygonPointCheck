package com.example.car300.ultils;

public class CheckTools {
    private CheckTools() {
        throw new AssertionError("工具类禁止实例化");
    }

    /**
     * 射线法判断点是否在多边形内
     * @param pointX 待测点经度
     * @param pointY 待测点纬度
     * @return 是否在多边形内部或边界上
     */
    public static boolean isPointInPolygon(double pointX, double pointY,double[][] POLYGON) {
        boolean inside = false;
        double epsilon = 1e-10; // 浮点数精度容差

        // 检查经纬度是否在多边形外接矩形之外
        double minX = Double.MAX_VALUE, maxX = Double.MIN_VALUE;
        double minY = Double.MAX_VALUE, maxY = Double.MIN_VALUE;
        for (double[] point : POLYGON) {
            minX = Math.min(minX,  point[0]);
            maxX = Math.max(maxX,  point[0]);
            minY = Math.min(minY,  point[1]);
            maxY = Math.max(maxY,  point[1]);
        }
        if (pointX < minX || pointX > maxX || pointY < minY || pointY > maxY) {
            return false;
        }

        // 射线法
        for (int i = 0, j = POLYGON.length  - 1; i < POLYGON.length;  j = i++) {
            double xi = POLYGON[i][0], yi = POLYGON[i][1];
            double xj = POLYGON[j][0], yj = POLYGON[j][1];

            // 处理点在顶点上的情况
            if (Math.abs(xi  - pointX) < epsilon && Math.abs(yi  - pointY) < epsilon) {
                return true;
            }

            // 检查射线与边的相交性
            if ((yi > pointY) != (yj > pointY)) {
                // 计算交点经度
                double slope = (xj - xi) / (yj - yi);
                double intersectX = xi + (pointY - yi) * slope;

                // 处理点在边上的情况
                if (Math.abs(intersectX  - pointX) < epsilon) {
                    return true;
                }

                // 统计右侧交点
                if (intersectX > pointX) {
                    inside = !inside;
                }
            }
        }
        return inside;
    }
}
