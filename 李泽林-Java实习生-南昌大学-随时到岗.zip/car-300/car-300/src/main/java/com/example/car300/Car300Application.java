package com.example.car300;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Car300Application {

    public static void main(String[] args) {
        SpringApplication.run(Car300Application.class, args);
    }

}
