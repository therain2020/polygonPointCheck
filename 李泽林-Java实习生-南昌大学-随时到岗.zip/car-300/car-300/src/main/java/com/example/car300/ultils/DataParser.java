package com.example.car300.ultils;

import java.util.List;

public class DataParser {
    private DataParser() {
        throw new AssertionError("工具类禁止实例化");
    }
    /**
     * 解析数据
     * @param content 文件字符串
     * @param xList 往两个集合里面添加元素，这是第一个集合
     * @param yList 往两个集合里面添加元素，这是第二个集合
     */
    public static void parseCoordinates(String content, List<Double> xList, List<Double> yList) {
        for (String line : content.split("\\r?\\n")) {
            if (line.trim().isEmpty()) continue; // 跳过空行

            // 解析逻辑
            String[] parts = line.split(" |, "); // 处理逗号和逗号加空格
            if (parts.length != 2) {
                throw new IllegalArgumentException("数据格式错误: " + line);
            }

            try {
                xList.add(Double.parseDouble(parts[0].trim()));
                yList.add(Double.parseDouble(parts[1].trim()));
            } catch (NumberFormatException e) {
                throw new RuntimeException("坐标转换失败: " + line, e);
            }
        }
    }

    /**
     * 数据结构转换方法
     * @param points 集合的集合
     * @return 二维数组
     */
    public static double[][] convertToArray(List<List<Double>> points) {
        double[][] arr = new double[points.size()][2];
        for (int i=0; i<points.size();  i++) {
            List<Double> point = points.get(i);
            arr[i][0] = point.get(0);
            arr[i][1] = point.get(1);
        }
        return arr;
    }
}