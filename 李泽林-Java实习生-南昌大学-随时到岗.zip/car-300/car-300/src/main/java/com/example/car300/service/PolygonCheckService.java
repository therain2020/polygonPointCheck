package com.example.car300.service;

import com.example.car300.ultils.CheckTools;
import com.example.car300.ultils.DataParser;
import com.example.car300.ultils.ResourceLoader;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.List;

@Service
public class PolygonCheckService implements CommandLineRunner {
    private final Gson gson = new Gson();

    @Override
    public void run(String... args) {
        // 移植原PolygonPointCheck.main 逻辑至此
        String content = ResourceLoader.readResource("points.txt");
        String jsonContent = ResourceLoader.readResource("latlon.json");

        // 泛型集合
        List<Double> xList = new ArrayList<>();
        List<Double> yList = new ArrayList<>();
        List<List<Double>> points = gson.fromJson(jsonContent,
                new TypeToken<List<List<Double>>>(){}.getType());

        // 调用封装的方法解析数据
        DataParser.parseCoordinates(content,  xList, yList);

        double[] x = xList.stream().mapToDouble(Double::doubleValue).toArray();
        double[] y = yList.stream().mapToDouble(Double::doubleValue).toArray();
        double[][] POLYGON = DataParser.convertToArray(points);

        for (int i = 0; i < xList.size(); i++) {
            System.out.println(x[i]+","+y[i]);
            System.out.println(" 点是否在多边形内: " + CheckTools.isPointInPolygon(x[i], y[i],POLYGON));
        }
    }
}
