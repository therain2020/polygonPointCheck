package com.example.car300.ultils;

import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

public final class ResourceLoader  {
    //工具类禁止实例化
    private ResourceLoader () {
        throw new AssertionError("工具类禁止实例化");
    }
    /**
     * 以UTF-8编码读取资源文件
     * @param filename 资源路径（相对于resources根目录）
     * @return 文件内容字符串
     * @throws ResourceLoadException 资源加载异常
     */
    public static String readResource(String filename) {
        return readResource(filename, StandardCharsets.UTF_8);
    }
    /**
     * 指定字符集读取资源文件
     * @param filename 资源路径
     * @param charset 字符集编码
     * @return 文件内容字符串
     * @throws ResourceLoadException 资源加载异常
     */
    public static String readResource(String filename, Charset charset) {
        validateFilename(filename);

        try (InputStream is = getResourceStream(filename)) {
            return new String(is.readAllBytes(),  charset);
        } catch (Exception e) {
            throw new ResourceLoadException("资源加载失败: " + filename, e);
        }
    }

    // 获取资源输入流（带空指针检查）
    private static InputStream getResourceStream(String filename) {
        InputStream is = Thread.currentThread()
                .getContextClassLoader()
                .getResourceAsStream(filename);

        if (is == null) {
            throw new ResourceLoadException("资源文件不存在: " + filename);
        }
        return is;
    }

    // 文件名合法性校验
    private static void validateFilename(String filename) {
        if (filename == null || filename.trim().isEmpty())  {
            throw new IllegalArgumentException("文件名不能为空");
        }
        if (filename.contains(".."))  {
            throw new SecurityException("禁止访问上级目录: " + filename);
        }
    }

}

/**
 * 自定义资源加载异常（增强错误信息）
 */
class ResourceLoadException extends RuntimeException {
    public ResourceLoadException(String message, Throwable cause) {
        super(message, cause);
    }
    public ResourceLoadException(String message) {
        super(message);
    }
}