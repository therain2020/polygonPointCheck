package com.example.car300;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Car300ApplicationTests {

    @Test
    void contextLoads() {
    }

}
